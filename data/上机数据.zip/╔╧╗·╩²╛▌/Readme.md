（1）三个作业的train set，validation set和test set已经划分好，直接使用；
（2）数据的具体信息可在*.name文件或者官网中找到。